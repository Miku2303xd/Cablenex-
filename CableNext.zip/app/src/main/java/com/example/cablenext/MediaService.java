package com.example.cablenext;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.KeyEvent;

public class MediaService extends Service {
    private MediaSession session;
    private AudioTrack track;
    private volatile boolean running;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int clicks = 0;

    private final Runnable fire = () -> {
        int c = clicks; clicks = 0;
        if (c == 1) SwipeService.act(SwipeService.NEXT);
        else if (c == 2) SwipeService.act(SwipeService.PREV);
        else if (c >= 3) SwipeService.act(SwipeService.TAP);
    };

    @Override public void onCreate() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("cn", "Cable Next", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "cn")
                .setContentTitle("Cable Next activo")
                .setContentText("1 pulsación: siguiente · 2: anterior · 3: pausa")
                .setSmallIcon(android.R.drawable.ic_media_play).build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);

        session = new MediaSession(this, "CableNext");
        session.setCallback(new MediaSession.Callback() {
            @SuppressWarnings("deprecation")
            @Override public boolean onMediaButtonEvent(Intent i) {
                KeyEvent e = i.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (e == null || e.getAction() != KeyEvent.ACTION_DOWN || e.getRepeatCount() > 0) return true;
                switch (e.getKeyCode()) {
                    case KeyEvent.KEYCODE_HEADSETHOOK:
                    case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    case KeyEvent.KEYCODE_MEDIA_PLAY:
                    case KeyEvent.KEYCODE_MEDIA_PAUSE:
                        clicks++;
                        h.removeCallbacks(fire);
                        h.postDelayed(fire, 350);
                        break;
                    case KeyEvent.KEYCODE_MEDIA_NEXT: SwipeService.act(SwipeService.NEXT); break;
                    case KeyEvent.KEYCODE_MEDIA_PREVIOUS: SwipeService.act(SwipeService.PREV); break;
                }
                return true;
            }
        });
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                        | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(PlaybackState.STATE_PLAYING, 0, 1f).build());
        session.setActive(true);

        // Audio silencioso en bucle para mantener la prioridad de los botones
        int rate = 44100;
        int buf = Math.max(AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT), 4096);
        track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(buf).build();
        running = true;
        track.play();
        new Thread(() -> {
            short[] silence = new short[2048];
            while (running) track.write(silence, 0, silence.length);
        }).start();
    }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }

    @Override public void onDestroy() {
        running = false;
        h.removeCallbacks(fire);
        if (track != null) { track.stop(); track.release(); }
        if (session != null) { session.setActive(false); session.release(); }
    }

    @Override public IBinder onBind(Intent i) { return null; }
}

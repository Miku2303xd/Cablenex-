package com.example.cablenext;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SwipeService extends AccessibilityService {
    static final int NEXT = 1, PREV = 2, TAP = 3;
    static SwipeService inst;
    static volatile String pkg = "";
    static final Set<String> APPS = new HashSet<>(Arrays.asList(
            "com.zhiliaoapp.musically",   // TikTok
            "com.ss.android.ugc.trill",   // TikTok (Asia)
            "com.instagram.android"));    // Instagram

    @Override protected void onServiceConnected() { inst = this; }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && e.getPackageName() != null) {
            String p = e.getPackageName().toString();
            if (!p.equals("com.android.systemui")) pkg = p;
        }
    }

    @Override public void onInterrupt() {}

    @Override public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }

    static void act(int what) {
        SwipeService s = inst;
        if (s == null || !APPS.contains(pkg)) return;
        DisplayMetrics m = s.getResources().getDisplayMetrics();
        float x = m.widthPixels / 2f, h = m.heightPixels;
        Path p = new Path();
        long dur = 150;
        if (what == NEXT) { p.moveTo(x, h * 0.75f); p.lineTo(x, h * 0.25f); }
        else if (what == PREV) { p.moveTo(x, h * 0.25f); p.lineTo(x, h * 0.75f); }
        else { p.moveTo(x, h * 0.5f); dur = 50; }
        s.dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null);
    }
}

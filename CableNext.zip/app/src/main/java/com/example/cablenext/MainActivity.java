package com.example.cablenext;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        l.setPadding(pad, pad * 2, pad, pad);

        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Cable Next\n\nSigue estos pasos en orden:\n"
                + "1. Activa el servicio de accesibilidad «Cable Next».\n"
                + "2. Quita la restricción de batería.\n"
                + "3. Inicia el servicio y abre TikTok o Instagram.\n\n"
                + "Botón del cable:\n• 1 pulsación: siguiente video\n• 2 pulsaciones: video anterior\n• 3 pulsaciones: pausa/reanudar\n");
        l.addView(t);

        l.addView(btn("1. Abrir accesibilidad", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(btn("2. Batería sin restricciones", v ->
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())))));
        l.addView(btn("3. Iniciar servicio", v ->
                startForegroundService(new Intent(this, MediaService.class))));
        l.addView(btn("Detener servicio", v ->
                stopService(new Intent(this, MediaService.class))));
        setContentView(l);
    }

    private Button btn(String text, View.OnClickListener c) {
        Button x = new Button(this);
        x.setText(text);
        x.setOnClickListener(c);
        return x;
    }
}
